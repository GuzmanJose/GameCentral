var canvas;
var image;
var inp;
var myDiv;
var buttonColor;
var word = "";
var writtenWords = [];
var button;
var overCircle;
var valuePosition;
var valuePosition = 700;


var Comment = 	function (word) {
					this.class = "commentClass";
					this.y = valuePosition;
					this.x = 60;
					this.text = "<p>" + word + "</p>";

				}

function setup () {

	var valuePosition = 700;
	buttonColor = color(33, 183, 184);
	
	myDiv = document.getElementById('myCanvas');
	canvas = createCanvas(400, 780);
	canvas.parent(myDiv);
	img = loadImage("img/iphone.png");
	inp = createInput('');
	inp.input(myInputEvent);
	inp.size(260,50);
	inp.position(500, 700);

	var newDiv = createDiv("<p>"+"something1"+"</p>");
	newDiv.class("someClass");
	newDiv.parent(myDiv);
	newDiv.position(35,0); // x is still the same
	
	
}


function draw () {

	var distance = dist(mouseX, mouseY, 325, 655);

	if (distance < 50) {
		overCircle = true;
	}
	else {
		overCircle = false;
	}

	if (overCircle == true) {
		buttonColor = color(37, 123, 201);	
		cursor(HAND);
	}
	else {
		buttonColor = color(33, 183, 184);
		cursor(ARROW); 
	}

	fill(0);
	image(img, 0,0);
	textSize(18);
	text("" + word, 50,600);
	
	noStroke();	
	fill(buttonColor);
	button = ellipse(325, 655, 50, 50);

	for (var i = 0; i < writtenWords.length; i ++) {
			
			valuePosition -= 30;
			createDiv(Comment[i].text).class(Comment[i].class).parent(myDiv).position(35, Comment[i].position);
			
	}



	// for loop if i >0 cretaeDiv with specs in Comment
  	


}

console.log(word);


function myInputEvent(){
 
  word = this.value();
}

function mousePressed() {
	if (overCircle == true) {
		 writtenWords.push(new Comment(word));
	}
}










// function keyPressed() {
// 	if (keyCode == SHIFT) {
// 		buttonColor = color(37, 123, 201);
// 	}
// 	else {
// 		buttonColor = color(33, 183, 184);
// 	}
	
// }






